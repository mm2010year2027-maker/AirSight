from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from config import HORIZON_HOURS, MODEL_DIR, RANDOM_STATE, REPORT_DIR
from src.features import build_supervised_frame, chronological_split, feature_columns

CANDIDATES = ("Ridge", "Random Forest", "HistGradientBoosting")


def regression_metrics(y_true, y_pred) -> dict[str, float | int]:
    actual = np.asarray(y_true, dtype=float)
    predicted = np.asarray(y_pred, dtype=float)
    valid = np.isfinite(actual) & np.isfinite(predicted)
    actual, predicted = actual[valid], predicted[valid]
    if len(actual) == 0:
        raise ValueError("لا توجد أزواج صالحة لحساب المقاييس.")
    mae = float(mean_absolute_error(actual, predicted))
    rmse = float(np.sqrt(np.mean(np.square(actual - predicted))))
    r2 = float(r2_score(actual, predicted)) if len(actual) > 1 else float("nan")
    return {"n": int(len(actual)), "MAE": mae, "RMSE": rmse, "R2": r2}


def _build_pipeline(name: str, columns: list[str]) -> Pipeline:
    numeric = [c for c in columns if pd.api.types.is_numeric_dtype(pd.Series([], dtype="float64")) and c not in {"station", "wd"}]
    # Dataframe types can be object for columns containing missing numeric values;
    # known source numeric columns are explicitly coerced in feature construction.
    numeric = [c for c in columns if c not in {"station", "wd"}]
    categorical = [c for c in columns if c in {"station", "wd"}]
    scale = name == "Ridge"
    numeric_steps = [("imputer", SimpleImputer(strategy="median", keep_empty_features=True))]
    if scale:
        numeric_steps.append(("scaler", StandardScaler()))
    transformers = [("numeric", Pipeline(numeric_steps), numeric)]
    if categorical:
        categorical_pipe = Pipeline([
            ("imputer", SimpleImputer(strategy="constant", fill_value="unknown")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ])
        transformers.append(("categorical", categorical_pipe, categorical))
    preprocess = ColumnTransformer(transformers, remainder="drop", sparse_threshold=0.0)

    if name == "Ridge":
        estimator = Ridge(alpha=10.0)
    elif name == "Random Forest":
        estimator = RandomForestRegressor(
            n_estimators=100, max_depth=16, min_samples_leaf=3,
            max_features=0.8, n_jobs=-1, random_state=RANDOM_STATE,
        )
    elif name == "HistGradientBoosting":
        estimator = HistGradientBoostingRegressor(
            max_iter=180, learning_rate=0.08, max_leaf_nodes=31,
            l2_regularization=1.0, early_stopping=True, random_state=RANDOM_STATE,
        )
    else:
        raise ValueError(f"نموذج غير معروف: {name}")
    return Pipeline([("preprocess", preprocess), ("model", estimator)])


def _baseline_predictions(frame: pd.DataFrame) -> dict[str, pd.Series]:
    return {
        "Persistence (PM2.5 at t)": pd.to_numeric(frame["PM2.5"], errors="coerce"),
        "Daily seasonal (t-24h)": pd.to_numeric(frame["pm25_lag_24h"], errors="coerce"),
    }


def train_and_evaluate(
    raw: pd.DataFrame | None = None,
    model_dir: Path = MODEL_DIR,
    report_dir: Path = REPORT_DIR,
) -> dict[str, object]:
    """Train candidates, select on chronological validation, then test once."""
    from src.data_loader import load_dataset

    if raw is None:
        raw = load_dataset()
    model_dir, report_dir = Path(model_dir), Path(report_dir)
    model_dir.mkdir(parents=True, exist_ok=True)
    report_dir.mkdir(parents=True, exist_ok=True)

    supervised = build_supervised_frame(raw, HORIZON_HOURS)
    train, validation, test, boundaries = chronological_split(supervised)
    columns = feature_columns(supervised)
    x_train, y_train = train[columns], train["target_pm25"]
    x_val, y_val = validation[columns], validation["target_pm25"]

    validation_rows: list[dict[str, object]] = []
    validation_mae: dict[str, float] = {}
    for name in CANDIDATES:
        print(f"Fitting {name} on {len(x_train):,} training rows…", flush=True)
        pipeline = _build_pipeline(name, columns)
        pipeline.fit(x_train, y_train)
        prediction = pipeline.predict(x_val)
        scores = regression_metrics(y_val, prediction)
        validation_mae[name] = float(scores["MAE"])
        print(f"{name} validation MAE: {scores['MAE']:.3f} µg/m³", flush=True)
        validation_rows.append({"model": name, **scores, "kind": "model"})

    for name, prediction in _baseline_predictions(validation).items():
        scores = regression_metrics(y_val, prediction)
        validation_rows.append({"model": name, **scores, "kind": "baseline"})

    best_name = min(validation_mae, key=validation_mae.get)
    print(f"Selected by validation MAE: {best_name}; refitting before the held-out test…", flush=True)
    train_validation = pd.concat([train, validation], ignore_index=True)
    best_pipeline = _build_pipeline(best_name, columns)
    best_pipeline.fit(train_validation[columns], train_validation["target_pm25"])
    x_test, y_test = test[columns], test["target_pm25"]
    test_prediction = best_pipeline.predict(x_test)
    test_scores = regression_metrics(y_test, test_prediction)
    print(f"Held-out test results on all eligible model rows: {test_scores}", flush=True)

    # Compare the model and simple baselines on the exact same timestamps.
    baseline_values = _baseline_predictions(test)
    common_mask = test["target_pm25"].notna()
    for values in baseline_values.values():
        common_mask &= np.isfinite(values)
    common_test = test.loc[common_mask]
    common_y = common_test["target_pm25"]
    model_series = pd.Series(test_prediction, index=test.index).loc[common_test.index]
    test_rows: list[dict[str, object]] = [
        {"model": best_name, **regression_metrics(common_y, model_series), "kind": "selected_model_common_rows"}
    ]
    for name, values in baseline_values.items():
        test_rows.append({"model": name, **regression_metrics(common_y, values.loc[common_test.index]), "kind": "baseline_common_rows"})

    validation_table = pd.DataFrame(validation_rows).sort_values("MAE")
    test_table = pd.DataFrame(test_rows).sort_values("MAE")
    validation_table.to_csv(report_dir / "validation_comparison.csv", index=False)
    test_table.to_csv(report_dir / "test_comparison.csv", index=False)
    pd.DataFrame([{"model": best_name, **test_scores, "kind": "selected_model_all_eligible_test_rows"}]).to_csv(
        report_dir / "test_model_full_rows.csv", index=False
    )

    prediction_frame = test[["station", "timestamp", "target_timestamp", "target_pm25", "PM2.5", "pm25_lag_24h"]].copy()
    prediction_frame = prediction_frame.rename(columns={"PM2.5": "persistence_pm25_at_origin", "pm25_lag_24h": "seasonal_pm25_24h"})
    prediction_frame["prediction_pm25"] = test_prediction
    prediction_frame["absolute_error"] = np.abs(test_prediction - test["target_pm25"].to_numpy())
    prediction_frame.to_csv(report_dir / "test_predictions.csv", index=False)

    artifact = {
        "pipeline": best_pipeline,
        "model_name": best_name,
        "features": columns,
        "horizon_hours": HORIZON_HOURS,
        "train_end": boundaries["train_end"],
        "validation_end": boundaries["validation_end"],
    }
    artifact_path = model_dir / "best_model.joblib"
    temporary_path = model_dir / ".best_model.joblib.tmp"
    joblib.dump(artifact, temporary_path)
    temporary_path.replace(artifact_path)

    result: dict[str, object] = {
        "selected_model": best_name,
        "validation_comparison": validation_table.to_dict(orient="records"),
        "test_comparison": test_table.to_dict(orient="records"),
        "test_model_all_eligible_rows": test_scores,
        "test_common_rows": int(len(common_test)),
        "boundaries": boundaries,
        "rows": {"supervised": len(supervised), "train": len(train), "validation": len(validation), "test": len(test)},
        "artifact": str(artifact_path),
        "horizon_hours": HORIZON_HOURS,
    }
    (report_dir / "training_summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8"
    )
    return result


def load_model(path: Path = MODEL_DIR / "best_model.joblib") -> dict[str, object]:
    """Load only a locally generated trusted artifact; never load user uploads."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError("لم يُدرّب نموذج بعد. شغّل التدريب أولًا.")
    artifact = joblib.load(path)
    expected = {"pipeline", "model_name", "features", "horizon_hours"}
    if not isinstance(artifact, dict) or not expected.issubset(artifact):
        raise ValueError("ملف النموذج غير متوافق مع إصدار AirSight الحالي.")
    return artifact


def export_predictions(frame: pd.DataFrame, predictions, destination: Path) -> Path:
    """Write a prediction table while preserving target timestamps and stations."""
    if len(frame) != len(predictions):
        raise ValueError("عدد التنبؤات لا يطابق عدد السجلات.")
    result = frame[["station", "timestamp", "target_timestamp"]].copy()
    result["prediction_pm25"] = np.asarray(predictions, dtype=float)
    Path(destination).parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(destination, index=False)
    return Path(destination)
