from __future__ import annotations

import numpy as np
import pandas as pd

from config import HORIZON_HOURS

POLLUTANTS = ["PM2.5", "PM10", "SO2", "NO2", "CO", "O3"]
WEATHER = ["TEMP", "PRES", "DEWP", "RAIN", "WSPM"]
CATEGORICAL = ["wd", "station"]


def build_supervised_frame(raw: pd.DataFrame, horizon_hours: int = HORIZON_HOURS) -> pd.DataFrame:
    """Create one row per forecast origin, matching the target at exactly t+h."""
    if horizon_hours < 1:
        raise ValueError("يجب أن يكون أفق التوقع ساعة واحدة على الأقل.")
    required = {"year", "month", "day", "hour", "PM2.5", "station", *WEATHER, "wd"}
    missing = required.difference(raw.columns)
    if missing:
        raise ValueError("أعمدة غير متوفرة لهندسة الميزات: " + ", ".join(sorted(missing)))

    data = raw.copy()
    data.columns = [str(c).strip() for c in data.columns]
    data["timestamp"] = pd.to_datetime(
        {"year": data["year"], "month": data["month"], "day": data["day"], "hour": data["hour"]},
        errors="coerce",
    )
    data = data.dropna(subset=["timestamp", "station"])
    data["station"] = data["station"].astype(str)
    data = data.sort_values(["station", "timestamp"]).drop_duplicates(["station", "timestamp"], keep="last")

    for column in POLLUTANTS + WEATHER:
        if column in data.columns:
            data[column] = pd.to_numeric(data[column], errors="coerce")

    # Match exact clock times rather than row offsets, so a missing hour cannot
    # silently turn a 2-hour-old observation into a feature named "lag_1h".
    lag_source_columns = [c for c in POLLUTANTS + WEATHER if c in data.columns]
    lag_one = data[["station", "timestamp", *lag_source_columns]].copy()
    lag_one["timestamp"] = lag_one["timestamp"] + pd.Timedelta(hours=1)
    lag_one = lag_one.rename(columns={
        col: f"{col.lower().replace('.', '')}_lag_1h" for col in lag_source_columns
    })
    data = data.merge(lag_one, on=["station", "timestamp"], how="left", validate="one_to_one")
    for lag_hours in (3, 6, 24):
        lag_frame = data[["station", "timestamp", "PM2.5"]].copy()
        lag_frame["timestamp"] = lag_frame["timestamp"] + pd.Timedelta(hours=lag_hours)
        lag_frame = lag_frame.rename(columns={"PM2.5": f"pm25_lag_{lag_hours}h"})
        data = data.merge(lag_frame, on=["station", "timestamp"], how="left", validate="one_to_one")

    data["hour_sin"] = np.sin(2 * np.pi * data["hour"] / 24.0)
    data["hour_cos"] = np.cos(2 * np.pi * data["hour"] / 24.0)
    day_of_year = data["timestamp"].dt.day_of_year
    data["doy_sin"] = np.sin(2 * np.pi * day_of_year / 365.25)
    data["doy_cos"] = np.cos(2 * np.pi * day_of_year / 365.25)
    future_time = data["timestamp"] + pd.to_timedelta(horizon_hours, unit="h")
    data["target_hour_sin"] = np.sin(2 * np.pi * future_time.dt.hour / 24.0)
    data["target_hour_cos"] = np.cos(2 * np.pi * future_time.dt.hour / 24.0)

    target = data[["station", "timestamp", "PM2.5"]].copy()
    target["timestamp"] = target["timestamp"] - pd.to_timedelta(horizon_hours, unit="h")
    target = target.rename(columns={"PM2.5": "target_pm25"})
    target = target.drop_duplicates(["station", "timestamp"], keep="last")
    data = data.merge(target, on=["station", "timestamp"], how="left", validate="one_to_one")
    data["target_timestamp"] = data["timestamp"] + pd.to_timedelta(horizon_hours, unit="h")
    data = data.dropna(subset=["target_pm25"]).reset_index(drop=True)
    return data


def feature_columns(frame: pd.DataFrame) -> list[str]:
    excluded = {"No", "year", "month", "day", "hour", "timestamp", "target_timestamp", "target_pm25"}
    return [column for column in frame.columns if column not in excluded]


def chronological_split(
    frame: pd.DataFrame, train_fraction: float = 0.70, validation_fraction: float = 0.15
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, str]]:
    """Split all stations on shared timestamp boundaries; purge crossing targets."""
    if not 0.5 <= train_fraction < 0.9 or not 0.05 <= validation_fraction < 0.3:
        raise ValueError("نسب التقسيم خارج النطاق المدعوم.")
    timestamps = pd.Index(frame["timestamp"].dropna().sort_values().unique())
    if len(timestamps) < 20:
        raise ValueError("السجلات الزمنية غير كافية للتقسيم.")
    train_cut = timestamps[int(len(timestamps) * train_fraction)]
    validation_cut = timestamps[int(len(timestamps) * (train_fraction + validation_fraction))]
    origin = frame["timestamp"]
    target_time = frame["target_timestamp"]

    train = frame.loc[target_time < train_cut].copy()
    validation = frame.loc[(origin >= train_cut) & (target_time < validation_cut)].copy()
    test = frame.loc[origin >= validation_cut].copy()
    if min(len(train), len(validation), len(test)) == 0:
        raise ValueError("أحد أقسام التقسيم الزمني فارغ.")
    if train["target_timestamp"].max() >= validation["target_timestamp"].min():
        raise AssertionError("تداخل زمني بين التدريب والتحقق.")
    if validation["target_timestamp"].max() >= test["target_timestamp"].min():
        raise AssertionError("تداخل زمني بين التحقق والاختبار.")
    boundaries = {"train_end": str(train_cut), "validation_end": str(validation_cut)}
    return train, validation, test, boundaries
