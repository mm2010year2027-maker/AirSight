from __future__ import annotations

import argparse
import json

from src.data_loader import load_dataset
from src.modeling import train_and_evaluate


def main() -> None:
    parser = argparse.ArgumentParser(description="تدريب ومقارنة نماذج AirSight")
    parser.add_argument("--data", help="مسار CSV اختياري يتضمن station وحقول البيانات")
    args = parser.parse_args()
    raw = load_dataset(args.data) if args.data else load_dataset()
    print(f"Loaded {len(raw):,} hourly station records from {raw['station'].nunique()} stations")
    result = train_and_evaluate(raw)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
