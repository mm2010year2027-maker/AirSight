"""Core data and machine-learning functions for AirSight."""
