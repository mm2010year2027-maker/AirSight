from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from config import REPORT_DIR
from src.data_loader import describe_data, load_dataset


def create_data_profile() -> dict[str, object]:
    frame = load_dataset()
    profile = describe_data(frame)
    timestamps = pd.to_datetime(
        {"year": frame["year"], "month": frame["month"], "day": frame["day"], "hour": frame["hour"]},
        errors="coerce",
    )
    profile["start_timestamp"] = str(timestamps.min())
    profile["end_timestamp"] = str(timestamps.max())
    timed = frame.assign(_timestamp=timestamps).sort_values(["station", "_timestamp"])
    hourly_gaps = timed.groupby("station")["_timestamp"].diff().ne(pd.Timedelta(hours=1))
    profile["nonhourly_steps_per_station"] = int(hourly_gaps.sum() - frame["station"].nunique())
    profile["dataset_source"] = "UCI Beijing Multi-Site Air Quality, dataset id 501"
    profile["license"] = "CC BY 4.0; attribution required"

    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    missing = pd.DataFrame({
        "column": frame.columns,
        "missing_count": [int(frame[c].isna().sum()) for c in frame.columns],
        "missing_percent": [float(frame[c].isna().mean() * 100) for c in frame.columns],
    }).sort_values("missing_count", ascending=False)
    missing.to_csv(REPORT_DIR / "data_missingness.csv", index=False)
    frame["station"].value_counts().rename_axis("station").reset_index(name="rows").to_csv(
        REPORT_DIR / "rows_per_station.csv", index=False
    )
    (REPORT_DIR / "data_profile.json").write_text(
        json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return profile


if __name__ == "__main__":
    print(json.dumps(create_data_profile(), ensure_ascii=False, indent=2))
