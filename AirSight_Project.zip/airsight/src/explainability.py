from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance


def permutation_importance_table(
    fitted_pipeline,
    x_evaluation: pd.DataFrame,
    y_evaluation,
    max_rows: int = 5000,
    repeats: int = 3,
    random_state: int = 42,
) -> pd.DataFrame:
    """Estimate global feature importance on held-out evaluation data."""
    if max_rows < 100 or repeats < 1:
        raise ValueError("حجم العينة أو عدد التكرارات صغير جدًا.")
    if len(x_evaluation) == 0:
        raise ValueError("مجموعة التقييم فارغة.")
    sample_size = min(max_rows, len(x_evaluation))
    x_sample = x_evaluation.sample(n=sample_size, random_state=random_state)
    y_sample = y_evaluation.loc[x_sample.index]
    result = permutation_importance(
        fitted_pipeline,
        x_sample,
        y_sample,
        scoring="neg_mean_absolute_error",
        n_repeats=repeats,
        random_state=random_state,
        n_jobs=-1,
    )
    table = pd.DataFrame({
        "feature": x_evaluation.columns,
        "importance_mean": result.importances_mean,
        "importance_std": result.importances_std,
    })
    return table.sort_values("importance_mean", ascending=False, ignore_index=True)


def local_shap_table(
    fitted_pipeline,
    background: pd.DataFrame,
    instance: pd.DataFrame,
    max_background_rows: int = 40,
    random_state: int = 42,
) -> tuple[pd.DataFrame, float, float]:
    """Return approximate model-agnostic SHAP values for exactly one row.

    The categorical inputs are first transformed by the fitted pipeline. SHAP
    then explains the numeric model inputs relative to a training background.
    Contributions describe model behavior and are not causal effects.
    """
    if len(instance) != 1:
        raise ValueError("التفسير المحلي يتطلب عينة واحدة بالضبط.")
    if list(instance.columns) != list(background.columns):
        raise ValueError("أعمدة العينة والخلفية لا تتطابق.")
    if background.empty:
        raise ValueError("بيانات الخلفية فارغة.")
    try:
        import shap
    except ImportError as exc:
        raise RuntimeError("ثبّت مكتبة SHAP عبر pip install shap.") from exc

    background_sample = background.sample(
        n=min(max_background_rows, len(background)), random_state=random_state
    )
    preprocessor = fitted_pipeline.named_steps["preprocess"]
    estimator = fitted_pipeline.named_steps["model"]
    background_matrix = np.asarray(preprocessor.transform(background_sample), dtype=float)
    instance_matrix = np.asarray(preprocessor.transform(instance), dtype=float)
    names = list(preprocessor.get_feature_names_out())
    explainer = shap.Explainer(
        estimator.predict,
        background_matrix,
        algorithm="permutation",
        feature_names=names,
        seed=random_state,
    )
    explanation = explainer(instance_matrix, max_evals=2 * len(names) + 1)
    values = np.asarray(explanation.values, dtype=float).reshape(-1)
    base_value = float(np.asarray(explanation.base_values).reshape(-1)[0])
    prediction = float(fitted_pipeline.predict(instance)[0])
    table = pd.DataFrame({
        "feature": names,
        "transformed_value": instance_matrix[0].astype(float),
        "shap_value": values,
    })
    table["absolute_shap"] = table["shap_value"].abs()
    table = table.sort_values("absolute_shap", ascending=False, ignore_index=True)
    return table, base_value, prediction
