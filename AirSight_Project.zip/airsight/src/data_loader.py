from __future__ import annotations

from io import BytesIO
from pathlib import Path
from urllib.request import Request, urlopen
from zipfile import BadZipFile, ZipFile

import pandas as pd

from config import ARCHIVE_PATH, DATASET_URL, EXTRACTED_DIR, MAX_UPLOAD_BYTES, RAW_DIR

MAX_ARCHIVE_BYTES = 20 * 1024 * 1024
MAX_INNER_CSV_BYTES = 150 * 1024 * 1024
REQUIRED_COLUMNS = {
    "year", "month", "day", "hour", "PM2.5", "TEMP", "PRES", "DEWP", "RAIN", "wd", "WSPM"
}


def download_archive(destination: Path = ARCHIVE_PATH, force: bool = False) -> Path:
    """Download the official UCI archive with a strict size limit."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() and not force:
        if destination.stat().st_size > MAX_ARCHIVE_BYTES:
            raise ValueError("ملف الأرشيف الموجود يتجاوز الحد المسموح.")
        return destination

    request = Request(DATASET_URL, headers={"User-Agent": "AirSight/1.0 (academic project)"})
    temporary = destination.with_suffix(destination.suffix + ".part")
    total = 0
    try:
        with urlopen(request, timeout=45) as response, temporary.open("wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_ARCHIVE_BYTES:
                    raise ValueError("حجم تنزيل البيانات تجاوز الحد الآمن المحدد.")
                output.write(chunk)
        temporary.replace(destination)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    return destination


def _safe_csv_members(archive: ZipFile) -> list[str]:
    members = []
    for info in archive.infolist():
        path = Path(info.filename)
        if path.is_absolute() or ".." in path.parts:
            raise ValueError("الأرشيف يحتوي مسارًا غير آمن.")
        if path.name.startswith("PRSA_Data_") and path.suffix.lower() == ".csv":
            if info.file_size > MAX_INNER_CSV_BYTES:
                raise ValueError("أحد ملفات CSV أكبر من الحد المتوقع.")
            members.append(info.filename)
    if not members:
        raise ValueError("لم يُعثر على ملفات محطات CSV المتوقعة داخل الأرشيف.")
    return members


def extract_station_csvs(archive_path: Path = ARCHIVE_PATH, destination: Path = EXTRACTED_DIR) -> list[Path]:
    """Extract only the expected CSV files from UCI's nested ZIP archive."""
    archive_path = Path(archive_path)
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    existing = sorted(destination.glob("PRSA_Data_*.csv"))
    if len(existing) == 12:
        return existing
    for old in destination.glob("PRSA_Data_*.csv"):
        old.unlink()

    try:
        with ZipFile(archive_path) as outer:
            inner_name = next((n for n in outer.namelist() if n.endswith(".zip") and "/" not in n), None)
            if inner_name is None:
                raise ValueError("لم يُعثر على أرشيف المحطات الداخلي.")
            inner_bytes = outer.read(inner_name)
        with ZipFile(BytesIO(inner_bytes)) as inner:
            members = _safe_csv_members(inner)
            for member in members:
                target = destination / Path(member).name
                with inner.open(member) as source, target.open("wb") as output:
                    output.write(source.read(MAX_INNER_CSV_BYTES + 1))
                if target.stat().st_size > MAX_INNER_CSV_BYTES:
                    target.unlink(missing_ok=True)
                    raise ValueError("تجاوز ملف CSV حد الحجم المسموح.")
    except (BadZipFile, StopIteration) as exc:
        raise ValueError("أرشيف البيانات تالف أو غير مكتمل؛ أعد تنزيله.") from exc

    files = sorted(destination.glob("PRSA_Data_*.csv"))
    if len(files) != 12:
        raise ValueError(f"توقعنا 12 ملف محطة، لكن عُثر على {len(files)}.")
    return files


def load_dataset(csv_path: str | Path | None = None, download: bool = True) -> pd.DataFrame:
    """Load all station files, or validate and load a user-supplied CSV."""
    if csv_path is not None:
        path = Path(csv_path)
        if path.suffix.lower() != ".csv":
            raise ValueError("يُقبل ملف CSV فقط.")
        if not path.is_file() or path.stat().st_size > MAX_UPLOAD_BYTES:
            raise ValueError("الملف غير موجود أو يتجاوز حد 25 MB.")
        frame = pd.read_csv(path, na_values=["NA", "", " "])
        if "station" not in frame.columns:
            raise ValueError("يلزم أن يتضمن CSV عمود station مع اسم المحطة.")
        _validate_columns(frame)
        return frame

    if not ARCHIVE_PATH.exists():
        if not download:
            raise FileNotFoundError("البيانات غير موجودة. شغّل تنزيل البيانات أولًا.")
        download_archive()
    files = extract_station_csvs()
    frames = []
    for file in files:
        frame = pd.read_csv(file, na_values=["NA", "", " "])
        station = file.name.removeprefix("PRSA_Data_").split("_20130301")[0]
        frame["station"] = station
        frames.append(frame)
    combined = pd.concat(frames, ignore_index=True)
    _validate_columns(combined)
    return combined


def _validate_columns(frame: pd.DataFrame) -> None:
    missing = REQUIRED_COLUMNS.difference(frame.columns)
    if missing:
        raise ValueError("أعمدة مطلوبة مفقودة: " + ", ".join(sorted(missing)))
    if frame.empty:
        raise ValueError("الملف لا يحتوي أي سجلات.")
    if frame["station"].isna().any():
        raise ValueError("توجد سجلات من دون اسم محطة.")


def describe_data(frame: pd.DataFrame) -> dict[str, object]:
    """Return factual quality summaries computed from the loaded file."""
    missing = frame.isna().sum().sort_values(ascending=False)
    return {
        "rows": int(len(frame)),
        "columns": int(len(frame.columns)),
        "stations": sorted(frame["station"].dropna().astype(str).unique().tolist()),
        "missing_by_column": missing[missing > 0].astype(int).to_dict(),
        "duplicate_station_hours": int(frame.duplicated(["station", "year", "month", "day", "hour"]).sum()),
    }
