from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent
DATA_DIR = PROJECT_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
MODEL_DIR = PROJECT_DIR / "models"
REPORT_DIR = PROJECT_DIR / "reports"

ARCHIVE_PATH = RAW_DIR / "uci_beijing_multi_site.zip"
EXTRACTED_DIR = RAW_DIR / "beijing_multi_site"
DATASET_URL = (
    "https://archive.ics.uci.edu/static/public/501/"
    "beijing+multi+site+air+quality+data.zip"
)
DATASET_PAGE = "https://archive.ics.uci.edu/dataset/501/beijing+multi+site+air+quality+data"
HORIZON_HOURS = 6
MAX_UPLOAD_BYTES = 25 * 1024 * 1024
RANDOM_STATE = 42
