# مجموعة البيانات

المصدر المستخدم هو **Beijing Multi-Site Air Quality**، Song Chen (2017)، من مستودع UCI Machine Learning Repository: https://archive.ics.uci.edu/dataset/501/beijing+multi+site+air+quality+data .

تتضمن مجموعة البيانات 420,768 قراءة ساعية من 12 محطة، للفترة 2013-03-01 إلى 2017-02-28. الترخيص المعلن في صفحة UCI هو Creative Commons Attribution 4.0 International (CC BY 4.0). يرجى الإبقاء على الإسناد والاستشهاد بـ DOI: 10.24432/C5RK5G عند إعادة الاستخدام.

ينزل `src.data_loader` أرشيف UCI الرسمي إلى `data/raw/` ويستخرج ملفات المحطات. لا ترفع أو تنشر نسخة معدّلة من البيانات دون مراجعة شروط المصدر. الملفات الخام مستثناة من Git لتقليل حجم المستودع.
