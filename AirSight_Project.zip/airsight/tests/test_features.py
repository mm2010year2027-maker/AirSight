import pandas as pd

from src.features import build_supervised_frame, chronological_split


def make_frame(hours=72):
    rows = []
    for station, offset in [("A", 0), ("B", 100)]:
        for i, timestamp in enumerate(pd.date_range("2020-01-01", periods=hours, freq="h")):
            rows.append({
                "station": station,
                "year": timestamp.year,
                "month": timestamp.month,
                "day": timestamp.day,
                "hour": timestamp.hour,
                "PM2.5": offset + i,
                "PM10": offset + i + 1,
                "SO2": 2,
                "NO2": 3,
                "CO": 4,
                "O3": 5,
                "TEMP": 10 + i / 10,
                "PRES": 1000,
                "DEWP": 4,
                "RAIN": 0,
                "wd": "N",
                "WSPM": 1.2,
            })
    return pd.DataFrame(rows)


def test_target_is_matched_exactly_six_hours_later_and_within_station():
    frame = build_supervised_frame(make_frame())
    row = frame[(frame.station == "A") & (frame.timestamp == pd.Timestamp("2020-01-01 02:00:00"))].iloc[0]
    assert row.target_timestamp == pd.Timestamp("2020-01-01 08:00:00")
    assert row.target_pm25 == 8
    row_b = frame[(frame.station == "B") & (frame.timestamp == pd.Timestamp("2020-01-01 02:00:00"))].iloc[0]
    assert row_b.target_pm25 == 108


def test_lag_features_do_not_cross_station_boundaries():
    frame = build_supervised_frame(make_frame())
    first_b = frame[(frame.station == "B") & (frame.timestamp == pd.Timestamp("2020-01-01 06:00:00"))].iloc[0]
    assert first_b.pm25_lag_1h == 105


def test_temporal_split_keeps_target_intervals_disjoint():
    frame = build_supervised_frame(make_frame(240))
    train, validation, test, _ = chronological_split(frame)
    assert train.target_timestamp.max() < validation.target_timestamp.min()
    assert validation.target_timestamp.max() < test.target_timestamp.min()
    assert train.timestamp.max() < validation.timestamp.max()
    assert set(train.timestamp).isdisjoint(set(test.timestamp))


def test_lag_uses_exact_clock_hour_when_a_station_row_is_missing():
    frame = make_frame(48)
    missing_time = pd.Timestamp("2020-01-01 05:00:00")
    frame = frame.loc[~((frame.station == "A") & (frame.hour == missing_time.hour) & (frame.day == missing_time.day))]
    supervised = build_supervised_frame(frame)
    row = supervised[(supervised.station == "A") & (supervised.timestamp == pd.Timestamp("2020-01-01 06:00:00"))].iloc[0]
    assert pd.isna(row.pm25_lag_1h)
    assert row.target_pm25 == 12
