import numpy as np
import pandas as pd
import pytest

from src.modeling import _build_pipeline, export_predictions, regression_metrics


def test_regression_metrics_are_computed_correctly():
    result = regression_metrics([1, 2, 3], [1, 2, 5])
    assert result["n"] == 3
    assert result["MAE"] == pytest.approx(2 / 3)
    assert result["RMSE"] == pytest.approx((4 / 3) ** 0.5)


def test_pipeline_fits_with_missing_numeric_and_unknown_category():
    x = pd.DataFrame({"station": ["A", "A", "B", "B"], "wd": ["N", "S", "E", "W"], "value": [1.0, np.nan, 3.0, 4.0]})
    y = np.array([1.0, 2.0, 3.0, 4.0])
    pipeline = _build_pipeline("Ridge", list(x.columns))
    pipeline.fit(x, y)
    prediction = pipeline.predict(pd.DataFrame({"station": ["new"], "wd": ["N"], "value": [2.0]}))
    assert prediction.shape == (1,)
    assert np.isfinite(prediction[0])


def test_export_predictions_validates_lengths(tmp_path):
    frame = pd.DataFrame({
        "station": ["A"],
        "timestamp": [pd.Timestamp("2020-01-01")],
        "target_timestamp": [pd.Timestamp("2020-01-01 06:00")],
    })
    output = export_predictions(frame, [12.5], tmp_path / "nested" / "predictions.csv")
    saved = pd.read_csv(output)
    assert saved.loc[0, "prediction_pm25"] == 12.5
    with pytest.raises(ValueError):
        export_predictions(frame, [], tmp_path / "bad.csv")


def test_model_artifact_is_saved_and_reloaded(tmp_path):
    import joblib

    from src.modeling import load_model

    x = pd.DataFrame({"station": ["A", "A", "B", "B"], "wd": ["N", "S", "E", "W"], "value": [1.0, 2.0, 3.0, 4.0]})
    y = np.array([1.0, 2.0, 3.0, 4.0])
    pipeline = _build_pipeline("Ridge", list(x.columns)).fit(x, y)
    artifact_path = tmp_path / "model.joblib"
    joblib.dump({
        "pipeline": pipeline,
        "model_name": "Ridge",
        "features": list(x.columns),
        "horizon_hours": 6,
    }, artifact_path)
    artifact = load_model(artifact_path)
    assert artifact["model_name"] == "Ridge"
    assert np.isfinite(artifact["pipeline"].predict(x.iloc[:1])[0])


def test_model_loader_rejects_unexpected_artifact(tmp_path):
    import joblib

    from src.modeling import load_model

    path = tmp_path / "wrong.joblib"
    joblib.dump({"unexpected": True}, path)
    with pytest.raises(ValueError, match="غير متوافق"):
        load_model(path)
