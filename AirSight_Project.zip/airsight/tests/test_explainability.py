import numpy as np
import pandas as pd
import pytest

from src.explainability import local_shap_table
from src.modeling import _build_pipeline


def test_local_shap_explains_single_instance_relative_to_background():
    x = pd.DataFrame({
        "station": ["A", "A", "B", "B", "A", "B"],
        "wd": ["N", "S", "E", "W", "N", "E"],
        "value": [1.0, 2.0, 3.0, 4.0, 1.5, 3.5],
    })
    y = np.array([1.0, 2.0, 3.0, 4.0, 1.5, 3.5])
    model = _build_pipeline("Ridge", list(x.columns)).fit(x, y)
    table, base_value, prediction = local_shap_table(model, x.iloc[:4], x.iloc[[4]])
    assert len(table) == len(model.named_steps["preprocess"].get_feature_names_out())
    assert np.isfinite(base_value)
    assert np.isfinite(prediction)
    assert table.absolute_shap.is_monotonic_decreasing


def test_local_shap_rejects_more_than_one_instance():
    x = pd.DataFrame({"value": [1.0, 2.0, 3.0]})
    model = _build_pipeline("Ridge", ["value"]).fit(x, np.array([1.0, 2.0, 3.0]))
    with pytest.raises(ValueError, match="عينة واحدة"):
        local_shap_table(model, x, x.iloc[:2])
