import pandas as pd
import pytest

from src.data_loader import load_dataset


def valid_row():
    return {
        "year": 2020, "month": 1, "day": 1, "hour": 0,
        "PM2.5": 10, "TEMP": 2, "PRES": 1000, "DEWP": 1,
        "RAIN": 0, "wd": "N", "WSPM": 1.0, "station": "A",
    }


def test_load_csv_validates_required_columns(tmp_path):
    path = tmp_path / "input.csv"
    pd.DataFrame([valid_row()]).to_csv(path, index=False)
    frame = load_dataset(path, download=False)
    assert len(frame) == 1
    assert frame.loc[0, "station"] == "A"


def test_load_csv_rejects_missing_station_column(tmp_path):
    row = valid_row()
    row.pop("station")
    path = tmp_path / "missing.csv"
    pd.DataFrame([row]).to_csv(path, index=False)
    with pytest.raises(ValueError, match="station"):
        load_dataset(path, download=False)


def test_load_csv_rejects_non_csv(tmp_path):
    path = tmp_path / "not_csv.txt"
    path.write_text("no data")
    with pytest.raises(ValueError, match="CSV"):
        load_dataset(path, download=False)
