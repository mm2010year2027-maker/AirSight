from __future__ import annotations

import tempfile

import pandas as pd
import plotly.express as px
import streamlit as st

from config import MAX_UPLOAD_BYTES, MODEL_DIR, PROCESSED_DIR, REPORT_DIR
from src.data_loader import describe_data, load_dataset
from src.explainability import permutation_importance_table
from src.features import build_supervised_frame, chronological_split, feature_columns
from src.modeling import load_model, train_and_evaluate

st.set_page_config(page_title="AirSight | بصيرة الهواء", page_icon="🌫️", layout="wide")

TEXT = {
    "ar": {
        "title": "AirSight | بصيرة الهواء",
        "subtitle": "توقع تجريبي قابل للتفسير لتركيز PM2.5 بعد ست ساعات.",
        "language": "اللغة / Language",
        "nav": "القسم",
        "pages": ["الرئيسية", "البيانات", "التدريب والتقييم", "إعادة تشغيل التوقع", "تفسير النموذج"],
        "disclaimer": "نطاق تجريبي تاريخي: بيانات بكين 2013–2017. ليس توقعًا حيًا أو نصيحة صحية ولا يمثل مدينة أخرى.",
        "load": "تحميل بيانات UCI الرسمية",
        "upload": "أو ارفع CSV يتضمن عمود station",
        "choose_file": "اختر ملف CSV (حتى 25 MB)",
        "data_needed": "حمّل مجموعة البيانات أو ارفع ملف CSV للمتابعة.",
        "data": "ملخص البيانات الفعلية",
        "rows": "السجلات", "columns": "الأعمدة", "stations": "المحطات", "duplicates": "تكرارات المحطة/الساعة",
        "missing": "القيم المفقودة حسب العمود",
        "preview": "معاينة البيانات",
        "train": "ابدأ التدريب والمقارنة",
        "training": "قد يستغرق التدريب وقتًا على الحاسوب الشخصي. لا تغلق التطبيق أثناء التنفيذ.",
        "no_results": "لا توجد نتائج تدريب بعد. اضغط زر التدريب أو شغّل python -m src.train.",
        "val": "مقارنة التحقق الزمني", "test": "المقارنة على الاختبار المحجوز",
        "forecast": "إعادة تشغيل على فترة الاختبار التاريخية",
        "station": "المحطة", "time": "وقت بداية التوقع", "pred": "توقع PM2.5 بعد 6 ساعات",
        "actual": "القراءة الفعلية بعد 6 ساعات (للمراجعة التاريخية)",
        "target_time": "وقت الهدف", "export": "تنزيل CSV للتوقعات",
        "explain": "الأهمية العامة تقيس أثر تبديل الميزات؛ وSHAP المحلي يفسر عينة واحدة نسبة إلى خلفية التدريب. كلاهما يصف النموذج لا السببية.",
        "run_explain": "احسب الأهمية العامة (Permutation)",
        "run_local": "احسب تفسير SHAP لهذه العينة",
        "selected_sample": "عينة الاختبار للتفسير",
        "base_value": "توقع الأساس للخلفية",
        "local_prediction": "توقع النموذج للعينة",
        "model": "النموذج المختار", "error": "حدث خطأ", "empty_test": "لا توجد سجلات اختبار مناسبة لهذا الاختيار.",
        "english": "English", "arabic": "العربية", "not_trained": "لم يُعثر على نموذج محفوظ.",
    },
    "en": {
        "title": "AirSight | بصيرة الهواء",
        "subtitle": "An explainable experimental six-hour PM2.5 forecast.",
        "language": "Language / اللغة", "nav": "Section",
        "pages": ["Home", "Data", "Training & evaluation", "Forecast replay", "Model explanation"],
        "disclaimer": "Historical proof of concept: Beijing 2013–2017. Not live, not medical advice, and not transferable to another city by default.",
        "load": "Load official UCI dataset", "upload": "Or upload a CSV with a station column",
        "choose_file": "Choose CSV (up to 25 MB)", "data_needed": "Load the dataset or upload a CSV to continue.",
        "data": "Observed dataset summary", "rows": "Rows", "columns": "Columns", "stations": "Stations",
        "duplicates": "Duplicate station-hours", "missing": "Missing values by column", "preview": "Data preview",
        "train": "Train and compare models", "training": "Training may take time on a personal computer. Keep the app open.",
        "no_results": "No training results yet. Start training or run python -m src.train.",
        "val": "Chronological validation comparison", "test": "Held-out test comparison",
        "forecast": "Replay the historical held-out period", "station": "Station", "time": "Forecast origin",
        "pred": "PM2.5 forecast in 6 hours", "actual": "Observed PM2.5 in 6 hours (historical review)",
        "target_time": "Target time", "export": "Download predictions CSV",
        "explain": "Global importance measures performance change under feature permutation; local SHAP explains one row relative to training background. Neither is causal.",
        "run_explain": "Calculate global Permutation Importance",
        "run_local": "Explain this row with SHAP",
        "selected_sample": "Held-out test sample",
        "base_value": "Background baseline prediction",
        "local_prediction": "Model prediction for this row",
        "model": "Selected model", "error": "Error",
        "empty_test": "No eligible test rows for this selection.", "english": "English", "arabic": "العربية",
        "not_trained": "No saved model found.",
    },
}

lang_choice = st.sidebar.radio("اللغة / Language", ["العربية", "English"], horizontal=True)
lang = "ar" if lang_choice == "العربية" else "en"
t = TEXT[lang]
if lang == "ar":
    st.markdown("<style>.block-container{direction:rtl;text-align:right} div[data-testid='stMetric']{direction:rtl}</style>", unsafe_allow_html=True)

st.title(t["title"])
st.caption(t["subtitle"])
st.warning(t["disclaimer"])
page = st.sidebar.selectbox(t["nav"], t["pages"])


def get_loaded_data():
    return st.session_state.get("airsight_frame")


def store_upload(uploaded_file):
    payload = uploaded_file.getvalue()
    if len(payload) > MAX_UPLOAD_BYTES:
        raise ValueError("الملف يتجاوز حد 25 MB.")
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(suffix=".csv", dir=PROCESSED_DIR, delete=False) as handle:
        handle.write(payload)
        temp_path = Path(handle.name)
    try:
        frame = load_dataset(temp_path, download=False)
    finally:
        temp_path.unlink(missing_ok=True)
    return frame


if page == t["pages"][0]:
    st.subheader(t["title"])
    st.write(t["subtitle"])
    st.markdown("**النطاق:** هدف متغير زمني مستقبلي، مقارنة مع الاستمرارية، وتفسير وصفي لأهمية الميزات. لا تُعرض أرقام تجريبية قبل تشغيل التدريب.")
    st.info("ابدأ من صفحة البيانات لتحميل المصدر الرسمي. بعد ذلك شغّل التدريب، ثم استكشف التوقعات على فترة الاختبار المحجوزة.")

elif page == t["pages"][1]:
    st.subheader(t["data"])
    upload = st.file_uploader(t["choose_file"], type=["csv"], help=t["upload"])
    left, right = st.columns(2)
    if left.button(t["load"], type="primary"):
        try:
            with st.spinner("Loading UCI data…"):
                st.session_state["airsight_frame"] = load_dataset()
        except Exception as exc:
            st.error(f"{t['error']}: {exc}")
    if upload is not None and right.button(t["upload"], key="upload_data"):
        try:
            st.session_state["airsight_frame"] = store_upload(upload)
        except Exception as exc:
            st.error(f"{t['error']}: {exc}")
    frame = get_loaded_data()
    if frame is None:
        st.info(t["data_needed"])
    else:
        summary = describe_data(frame)
        c1, c2, c3, c4 = st.columns(4)
        c1.metric(t["rows"], f"{summary['rows']:,}")
        c2.metric(t["columns"], summary["columns"])
        c3.metric(t["stations"], len(summary["stations"]))
        c4.metric(t["duplicates"], summary["duplicate_station_hours"])
        st.write(t["missing"])
        missing = pd.Series(summary["missing_by_column"], dtype="int64")
        st.dataframe(missing.rename("count").to_frame(), use_container_width=True)
        st.write(t["preview"])
        st.dataframe(frame.head(30), use_container_width=True)

elif page == t["pages"][2]:
    st.subheader(t["pages"][2])
    st.write(t["training"])
    frame = get_loaded_data()
    if frame is None:
        st.info(t["data_needed"])
    elif st.button(t["train"], type="primary"):
        try:
            with st.spinner("Training candidate models and evaluating…"):
                result = train_and_evaluate(frame)
            st.success(f"{t['model']}: {result['selected_model']}")
            st.dataframe(pd.DataFrame(result["validation_comparison"]), use_container_width=True)
            st.dataframe(pd.DataFrame(result["test_comparison"]), use_container_width=True)
        except Exception as exc:
            st.exception(exc)
    validation_path = REPORT_DIR / "validation_comparison.csv"
    test_path = REPORT_DIR / "test_comparison.csv"
    if validation_path.exists() and test_path.exists():
        st.subheader(t["val"])
        validation = pd.read_csv(validation_path)
        st.dataframe(validation, use_container_width=True)
        st.subheader(t["test"])
        test = pd.read_csv(test_path)
        st.dataframe(test, use_container_width=True)
        chart = px.bar(validation, x="model", y="MAE", color="kind", title="MAE — validation" if lang == "en" else "متوسط الخطأ المطلق — التحقق")
        st.plotly_chart(chart, use_container_width=True)
    else:
        st.info(t["no_results"])

elif page == t["pages"][3]:
    st.subheader(t["forecast"])
    raw = get_loaded_data()
    try:
        artifact = load_model()
    except Exception:
        artifact = None
    if raw is None:
        st.info(t["data_needed"])
    elif artifact is None:
        st.info(t["not_trained"])
    else:
        supervised = build_supervised_frame(raw, int(artifact["horizon_hours"]))
        test_start = pd.Timestamp(artifact["validation_end"])
        held_out = supervised.loc[supervised["timestamp"] >= test_start].copy()
        if held_out.empty:
            st.info(t["empty_test"])
        else:
            stations = sorted(held_out["station"].astype(str).unique())
            station = st.selectbox(t["station"], stations)
            station_rows = held_out.loc[held_out["station"].astype(str) == station].sort_values("timestamp")
            timestamps = station_rows["timestamp"].drop_duplicates().tolist()
            selected_time = st.select_slider(t["time"], options=timestamps, value=timestamps[-1])
            row = station_rows.loc[station_rows["timestamp"] == selected_time].iloc[[0]]
            x = row[artifact["features"]]
            prediction = float(artifact["pipeline"].predict(x)[0])
            col1, col2 = st.columns(2)
            col1.metric(t["pred"], f"{prediction:.2f} µg/m³")
            col2.metric(t["actual"], f"{float(row['target_pm25'].iloc[0]):.2f} µg/m³")
            st.write(f"{t['target_time']}: {row['target_timestamp'].iloc[0]}")
            # Show the 7 days leading up to the chosen target timestamp.
            target_timestamp = row["target_timestamp"].iloc[0]
            chart_data = station_rows.loc[
                (station_rows["target_timestamp"] >= target_timestamp - pd.Timedelta(days=7))
                & (station_rows["target_timestamp"] <= target_timestamp),
                ["target_timestamp", "target_pm25"],
            ].rename(columns={"target_timestamp": "time", "target_pm25": "Observed PM2.5"})
            chart_data["Forecast at selected time"] = float("nan")
            chart_data.loc[chart_data["time"] == target_timestamp, "Forecast at selected time"] = prediction
            st.plotly_chart(px.line(chart_data, x="time", y=["Observed PM2.5", "Forecast at selected time"]), use_container_width=True)
            csv = pd.DataFrame({
                "station": [station], "forecast_origin": [row["timestamp"].iloc[0]],
                "target_time": [row["target_timestamp"].iloc[0]], "prediction_pm25": [prediction],
                "observed_pm25": [float(row["target_pm25"].iloc[0])],
            }).to_csv(index=False).encode("utf-8")
            st.download_button(t["export"], csv, file_name="airsight_forecast_replay.csv", mime="text/csv")

elif page == t["pages"][4]:
    st.subheader(t["pages"][4])
    st.write(t["explain"])
    raw = get_loaded_data()
    try:
        artifact = load_model()
    except Exception:
        artifact = None
    if raw is None:
        st.info(t["data_needed"])
    elif artifact is None:
        st.info(t["not_trained"])
    else:
        supervised = build_supervised_frame(raw, int(artifact["horizon_hours"]))
        train, validation, test, _ = chronological_split(supervised)
        stations = sorted(test["station"].astype(str).unique())
        selected_station = st.selectbox(t["station"], stations, key="explain_station")
        station_test = test.loc[test["station"].astype(str) == selected_station].sort_values("timestamp")
        times = station_test["timestamp"].drop_duplicates().tolist()
        selected_time = st.select_slider(t["selected_sample"], options=times, value=times[-1], key="explain_time")
        instance_row = station_test.loc[station_test["timestamp"] == selected_time].iloc[[0]]
        x_test, y_test = test[artifact["features"]], test["target_pm25"]
        if st.button(t["run_explain"]):
            try:
                table = permutation_importance_table(artifact["pipeline"], x_test, y_test)
                st.dataframe(table.head(20), use_container_width=True)
                st.plotly_chart(px.bar(table.head(15), x="importance_mean", y="feature", orientation="h", title="Permutation importance"), use_container_width=True)
            except Exception as exc:
                st.exception(exc)
        if st.button(t["run_local"]):
            try:
                background = pd.concat([train, validation], ignore_index=True)[artifact["features"]]
                local, base_value, prediction = local_shap_table(
                    artifact["pipeline"], background, instance_row[artifact["features"]]
                )
                col1, col2 = st.columns(2)
                col1.metric(t["base_value"], f"{base_value:.2f} µg/m³")
                col2.metric(t["local_prediction"], f"{prediction:.2f} µg/m³")
                st.caption("SHAP موجب يرفع التوقع نسبة إلى الأساس، والسالب يخفضه. القيم تقريبية وغير سببية." if lang == "ar" else "Positive SHAP values raise the prediction relative to the baseline; negative values lower it. Approximate, not causal.")
                st.dataframe(local.head(20), use_container_width=True)
                st.plotly_chart(px.bar(local.head(15), x="shap_value", y="feature", orientation="h", title="Local SHAP values"), use_container_width=True)
            except Exception as exc:
                st.exception(exc)

st.sidebar.caption("UCI data · CC BY 4.0 · AirSight research prototype")
